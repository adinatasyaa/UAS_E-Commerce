<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('produk', function (Blueprint $table) {
            // 1. Hapus kolom string kategori_produk yang lama
            if (Schema::hasColumn('produk', 'kategori_produk')) {
                $table->dropColumn('kategori_produk');
            }
            
            // 2. Tambah kolom foreign key baru setelah nama_produk (nullable agar aman jika belum ada kategori)
            $table->unsignedBigInteger('id_kategori_produk')->nullable()->after('nama_produk');
            
            // 3. Hubungkan ke id di tabel kategori
            $table->foreign('id_kategori_produk')->references('id')->on('kategori')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('produk', function (Blueprint $table) {
            $table->dropForeign(['id_kategori_produk']);
            $table->dropColumn('id_kategori_produk');
            $table->string('kategori_produk')->after('nama_produk');
        });
    }
};