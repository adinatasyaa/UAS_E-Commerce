<?php

namespace Database\Seeders;

use App\Models\Produk; 
use Illuminate\Database\Seeder;

class ProdukSeeder extends Seeder
{
    public function run(): void
    {
        Produk::factory()->count(1000)->create();
    }
}