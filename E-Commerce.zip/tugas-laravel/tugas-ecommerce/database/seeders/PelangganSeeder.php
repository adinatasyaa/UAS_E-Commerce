<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PelangganSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('pelanggan')->insert([
            [
                'nama_lengkap' => 'Adinda Natasya',
                'jenis_kelamin' => 'Perempuan',
                'nomor_hp' => '081234567890',
                'alamat_email' => 'adinda@gmail.com',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'nama_lengkap' => 'Felix',
                'jenis_kelamin' => 'Laki-laki',
                'nomor_hp' => '089876543210',
                'alamat_email' => 'felix@gmail.com',
                'created_at' => now(),
                'updated_at' => now(),
            ]
        ]);
    }
}