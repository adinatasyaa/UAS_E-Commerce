<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Kategori; 

class KategoriSeeder extends Seeder
{
    public function run(): void
    {
        $categories = [
            ['nama_kategori' => 'Pakaian'],
            ['nama_kategori' => 'Sepatu'],
            ['nama_kategori' => 'Elektronik'],
        ];

        foreach ($categories as $category) {
            Kategori::create($category); 
        }
    }
}