<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Produk Sepatu</title>
</head>
<body>
    <h2>Produk Sepatu</h2>
    <table border="1" cellpadding="10" cellspacing="0" style="width: 500px;">
        <tr>
            <td width="150">Nama Produk</td>
            <td>{{ $nama_produk }}</td>
        </tr>
        <tr>
            <td>Warna</td>
            <td>{{ $warna }}</td>
        </tr>
        <tr>
            <td>Ukuran</td>
            <td>{{ $ukuran }}</td>
        </tr>
        <tr>
            <td>Jumlah Stok</td>
            <td>{{ $stok }}</td>
        </tr>
    </table>
</body>
</html>