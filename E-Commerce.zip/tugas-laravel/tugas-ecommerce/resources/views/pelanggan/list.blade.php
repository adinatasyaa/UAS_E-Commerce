<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Pelanggan</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

    <style>
        .pagination svg {
            width: 16px;
            height: 16px;
        }
    </style>
</head>
<body class="container py-5">
    <div class="p-4 bg-white shadow-sm rounded-3">
        
        <form action="{{ url('/pelanggan') }}" method="GET" class="row mb-4 align-items-center">
            <div class="col-md-4">
                <div class="input-group">
                    <input type="text" name="q" value="{{ $q ?? '' }}" placeholder="Cari pelanggan..." class="form-control bg-light">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-search"></i> Cari
                    </button>
                </div>
            </div>
            <div class="col-md-8 text-end">
                <a href="{{ url('/pelanggan/create') }}" class="btn btn-primary px-4">Tambah</a>
            </div>
        </form>
        @if(session('success')) 
            <div class="alert alert-success rounded-3">{{ session('success') }}</div> 
        @endif

        <table class="table table-bordered table-striped align-middle">
            <thead class="table-light">
                <tr>
                    <th width="5%">No</th>
                    <th width="15%">Foto</th>
                    <th>Nama Pelanggan</th>
                    <th>Jenis Kelamin</th>
                    <th>Nomor HP</th>
                    <th>Email</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($result as $item)
                <tr>
                    <td>{{ $result->firstItem() + $loop->index }}</td>
                    <td><img src="{{ $item->foto_pelanggan }}" alt="Foto" width="80px" class="img-thumbnail rounded-3" /></td>
                    <td>{{ $item->nama_lengkap }}</td>
                    <td>{{ $item->jenis_kelamin }}</td>
                    <td>{{ $item->nomor_hp }}</td>
                    <td>{{ $item->alamat_email }}</td>
                <td class="text-center">
                    <a href="{{ url('/pelanggan/edit/'.$item->id) }}"class="btn btn-warning btn-sm">
                        Edit
                    </a>
                    <form action="{{ url('/pelanggan/destroy/'.$item->id) }}"
                        method="POST"
                        class="d-inline">

                        @csrf
                        @method('DELETE')

                        <button type="submit"
                            class="btn btn-danger btn-sm"
                            onclick="return confirm('Yakin hapus data?')">
                            Hapus
                        </button>
                    </form>
                </td>
                </tr>
                @empty
                <tr><td colspan="7" class="text-center text-muted py-4">Data pelanggan kosong.</td></tr>
                @endforelse
            </tbody>
        </table>

        <div class="mt-3">
            {{ $result->appends(['q' => $q ?? ''])->links() }}
        </div>
    </div>
</body>
</html>