<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Form Tambah Pelanggan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="d-flex align-items-center justify-content-center min-vh-screen py-5 bg-light">
    <div class="card p-4 shadow-sm w-100" style="max-width: 450px; border: none; border-radius: 12px;">
        <h2 class="text-center fs-4 mb-4 fw-bold">Form Tambah Pelanggan</h2>

        @if ($errors->any())
            <div class="alert alert-danger small rounded-3">
                <ul class="mb-0 ps-3">
                    @foreach ($errors->all() as $error) <li>{{ $error }}</li> @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('pelanggan.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="mb-3">
                <label class="form-label small fw-semibold text-secondary">Nama Lengkap:</label>
                <input type="text" name="nama_lengkap" value="{{ old('nama_lengkap') }}" class="form-control">
            </div>
            <div class="mb-3">
                <label class="form-label small fw-semibold text-secondary">Jenis Kelamin:</label>
                <select name="jenis_kelamin" class="form-select">
                    <option value="">- Pilih -</option>
                    <option value="Laki-laki" {{ old('jenis_kelamin') == 'Laki-laki' ? 'selected' : '' }}>Laki-laki</option>
                    <option value="Perempuan" {{ old('jenis_kelamin') == 'Perempuan' ? 'selected' : '' }}>Perempuan</option>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label small fw-semibold text-secondary">Nomor HP:</label>
                <input type="text" name="nomor_hp" value="{{ old('nomor_hp') }}" class="form-control">
            </div>
            <div class="mb-3">
                <label class="form-label small fw-semibold text-secondary">Alamat Email:</label>
                <input type="email" name="alamat_email" value="{{ old('alamat_email') }}" class="form-control">
            </div>
            <div class="mb-4">
                <label class="form-label small fw-semibold text-secondary">Foto Pelanggan:</label>
                <input type="file" name="foto_pelanggan" class="form-control">
            </div>
            <button type="submit" class="btn btn-success w-100 fw-semibold py-2 rounded-3">Simpan Data Pelanggan</button>
        </form>
    </div>
</body>
</html>