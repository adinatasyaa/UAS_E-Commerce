<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Tambah Produk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card-form {
            max-width: 450px;
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }
    </style>
</head>
<body class="d-flex align-items-center justify-content-center min-vh-screen">

    <div class="card card-form p-4 bg-white w-100">
        <h2 class="text-center fs-4 font-weight-bold text-dark mb-4">Form Tambah Produk</h2>

        @if ($errors->any())
            <div class="alert alert-danger rounded-3 shadow-sm mb-4" role="alert">
                <ul class="mb-0 ps-3 small">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('produk.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            
            <div class="mb-3">
                <label class="form-label fw-semibold text-secondary small">Kategori Produk:</label>
                <select name="id_kategori_produk" class="form-select bg-light">
                    <option value="">-Pilih Kategori-</option>
                    @foreach($kategori as $kat)
                        <option value="{{ $kat->id }}" {{ old('id_kategori_produk') == $kat->id ? 'selected' : '' }}>
                            {{ $kat->nama_kategori }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label fw-semibold text-secondary small">Nama Produk:</label>
                <input type="text" name="nama_produk" value="{{ old('nama_produk') }}" placeholder="Masukkan nama produk" class="form-control">
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold text-secondary small">Stok:</label>
                <input type="text" name="stok" value="{{ old('stok') }}" placeholder="Contoh: 10" class="form-control">
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold text-secondary small">Harga Produk:</label>
                <input type="text" name="harga_produk" value="{{ old('harga_produk') }}" placeholder="Contoh: 150000" class="form-control">
            </div>

            <div class="mb-4">
                <label class="form-label fw-semibold text-secondary small">Foto Produk:</label>
                @if(!empty($produk->foto_produk) && \Storage::exists('produk/'.$produk->getRawOriginal('foto_produk')))
                    <div class="mb-2">
                        <img src="{{ Storage::url('produk/'.$produk->getRawOriginal('foto_produk')) }}" alt="Foto Lama" width="100px" class="img-thumbnail" />
                    </div>
                @endif
                <input type="file" name="foto_produk" class="form-control">
            </div>

            <button type="submit" class="btn btn-success w-100 py-2.5 fw-semibold rounded-3 shadow-sm">
                Simpan Data Produk
            </button>
        </form>
    </div>

</body>
</html>