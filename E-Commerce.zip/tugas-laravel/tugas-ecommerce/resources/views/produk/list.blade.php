<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Produk</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

    <style>
        body{
            background-color:#f8f9fa;
        }

        .table-container{
            background:#fff;
            border-radius:10px;
            box-shadow:0 2px 10px rgba(0,0,0,.1);
            padding:20px;
        }

        .table img{
            width:80px;
            height:auto;
        }
    </style>
</head>
<body>

<div class="container py-5">

    <div class="table-container">

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="mb-0">Daftar Produk</h3>

            <a href="{{ url('/produk/create') }}" class="btn btn-primary">
                <i class="bi bi-plus-circle"></i>
                Tambah Produk
            </a>
        </div>

        <form action="{{ url('/produk') }}" method="GET" class="mb-4">
            <div class="input-group">
                <input
                    type="text"
                    name="q"
                    value="{{ $q ?? '' }}"
                    class="form-control"
                    placeholder="Cari nama produk atau kategori">

                <button class="btn btn-primary" type="submit">
                    <i class="bi bi-search"></i>
                    Cari
                </button>
            </div>
        </form>

        @if(session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        <div class="table-responsive">

            <table class="table table-bordered table-striped align-middle">

                <thead class="table-light">
                    <tr>
                        <th>No</th>
                        <th>Foto</th>
                        <th>Kategori</th>
                        <th>Nama Produk</th>
                        <th>Stok</th>
                        <th>Harga</th>
                        <th width="150">Aksi</th>
                    </tr>
                </thead>

                <tbody>

                @forelse($result as $item)

                    <tr>

                        <td>{{ $loop->iteration }}</td>

                        <td>
                            <img
                                src="{{ $item->foto_produk }}"
                                alt="Produk"
                                class="img-thumbnail">
                        </td>

                        <td>
                            {{ $item->kategori->nama_kategori ?? '-' }}
                        </td>

                        <td>
                            {{ $item->nama_produk }}
                        </td>

                        <td>
                            {{ $item->stok }}
                        </td>

                        <td>
                            Rp {{ number_format($item->harga_produk,0,',','.') }}
                        </td>

                        <td>

                            <a href="{{ url('/produk/edit/'.$item->id) }}"
                               class="btn btn-warning btn-sm">
                                Edit
                            </a>

                            <form action="{{ url('/produk/destroy/'.$item->id) }}"
                                  method="POST"
                                  class="d-inline">

                                @csrf
                                @method('DELETE')

                                <button
                                    type="submit"
                                    class="btn btn-danger btn-sm"
                                    onclick="return confirm('Yakin hapus data?')">
                                    Hapus
                                </button>

                            </form>

                        </td>

                    </tr>

                @empty

                    <tr>
                        <td colspan="7" class="text-center">
                            Data produk tidak ditemukan
                        </td>
                    </tr>

                @endforelse

                </tbody>

            </table>

                </div>

        <div class="d-flex justify-content-center mt-4">
    {{ $result->links('pagination::bootstrap-5') }}
</div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>