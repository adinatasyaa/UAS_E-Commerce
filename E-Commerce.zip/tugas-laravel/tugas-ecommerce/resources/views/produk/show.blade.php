<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Produk</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body{
            background:#f8f9fa;
        }
    </style>
</head>
<body>

<div class="container py-5">

    <div class="row justify-content-center">

        <div class="col-lg-7 col-md-8">

            <div class="card shadow border-0">

                <div class="card-body p-4">

                    <div class="alert alert-success">
                        Data Produk Berhasil Disimpan
                    </div>

                    <h3 class="mb-4">
                        Detail Produk
                    </h3>

                    <table class="table table-bordered">

                        <tr>
                            <th width="35%">Kategori Produk</th>
                            <td>{{ $data['kategori_produk'] }}</td>
                        </tr>

                        <tr>
                            <th>Nama Produk</th>
                            <td>{{ $data['nama_produk'] }}</td>
                        </tr>

                        <tr>
                            <th>Stok</th>
                            <td>{{ $data['stok'] }} Unit</td>
                        </tr>

                        <tr>
                            <th>Harga Produk</th>
                            <td>
                                Rp {{ number_format($data['harga_produk'],0,',','.') }}
                            </td>
                        </tr>

                    </table>

                    <div class="text-center">

                        <a href="{{ url('/produk') }}"
                           class="btn btn-secondary">
                            Kembali ke Daftar Produk
                        </a>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>

</body>
</html>