<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body{
            background:#f8f9fa;
        }
    </style>
</head>
<body>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-6 col-md-8">

            <div class="card shadow border-0">
                <div class="card-body p-4">

                    <h3 class="text-center mb-4">
                        Edit Produk
                    </h3>

                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <form action="{{ url('/produk/update/'.$produk->id) }}" method="POST" enctype="multipart/form-data">
                        @csrf

                        <div class="mb-3">
                            <label class="form-label">Kategori Produk</label>

                            <select name="id_kategori_produk" class="form-select">
                                <option value="">Pilih Kategori</option>

                                @foreach($kategori as $kat)
                                    <option value="{{ $kat->id }}"
                                        {{ old('id_kategori_produk',$produk->id_kategori_produk)==$kat->id ? 'selected' : '' }}>
                                        {{ $kat->nama_kategori }}
                                    </option>
                                @endforeach
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Nama Produk</label>

                            <input type="text"
                                   name="nama_produk"
                                   value="{{ old('nama_produk',$produk->nama_produk) }}"
                                   class="form-control">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Stok</label>

                            <input type="number"
                                   name="stok"
                                   value="{{ old('stok',$produk->stok) }}"
                                   class="form-control">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Harga Produk</label>

                            <input type="number"
                                   name="harga_produk"
                                   value="{{ old('harga_produk',$produk->harga_produk) }}"
                                   class="form-control">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Foto Produk</label>

                            @if(!empty($produk->getRawOriginal('foto_produk')))

                                <div class="mb-2">
                                    <img
                                        src="{{ Storage::url('produk/'.$produk->getRawOriginal('foto_produk')) }}"
                                        width="120"
                                        class="img-thumbnail">
                                </div>

                            @endif

                            <input type="file"
                                   name="foto_produk"
                                   class="form-control">

                            <small class="text-muted">
                                Kosongkan jika tidak ingin mengubah foto.
                            </small>
                        </div>

                        <div class="d-flex gap-2">
                            <a href="{{ url('/produk') }}"
                               class="btn btn-secondary w-50">
                                Kembali
                            </a>

                            <button type="submit"
                                    class="btn btn-warning w-50 text-white">
                                Update Produk
                            </button>
                        </div>

                    </form>

                </div>
            </div>

        </div>
    </div>
</div>

</body>
</html>