<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Biodata Saya</title>
</head>
<body>
    <h2>Biodata Saya</h2>
    <table border="1" cellpadding="10" cellspacing="0" style="width: 500px;">
        <tr>
            <td width="150">NIM</td>
            <td>{{ $nim }}</td>
        </tr>
        <tr>
            <td>Nama Lengkap</td>
            <td>{{ $nama }}</td>
        </tr>
        <tr>
            <td>Kelas</td>
            <td>{{ $kelas }}</td>
        </tr>
        <tr>
            <td>Jurusan</td>
            <td>{{ $jurusan }}</td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>{{ $alamat }}</td>
        </tr>
    </table>
</body>
</html>