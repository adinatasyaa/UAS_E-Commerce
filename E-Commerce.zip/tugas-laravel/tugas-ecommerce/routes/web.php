<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProdukController;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\PelangganController;


Route::get('/route-biodata', function () {
    $nim = "10522094";
    $nama = "Adinda Natasya";
    $kelas = "IS-3";
    $jurusan = "Sistem Informasi";
    $alamat = "Komp. Bukit Cinunuk Lestari Blok A-2 Jl. Ciguruwik";

    return view('biodata', compact('nim', 'nama', 'kelas', 'jurusan', 'alamat'));
});

Route::get('/route-dosen', function () {
    $nip = "41277826124";
    $nidn = "0423019401";
    $nama = "Ferry Stephanus Suwita";
    $tempat = "Bandung";
    $tanggal = "January 23, 1994";

    return view('dosen', compact('nip', 'nidn', 'nama', 'tempat', 'tanggal'));
});

Route::get('/route-produk', function () {
    $nama_produk = "Sepatu Sneakers";
    $warna = "Putih";
    $ukuran = "37";
    $stok = "28";

    return view('produk', compact('nama_produk', 'warna', 'ukuran', 'stok'));
});

Route::get('/biodata-array', function () {
    $data = [
        'nim' => '10522094',
        'nama' => 'Adinda Natasya',
        'kelas' => 'IS-3',
        'jurusan' => 'Sistem Informasi',
        'alamat' => 'Komp. Bukit Cinunuk Lestari Blok A-2 Jl. Ciguruwik'
    ];
    return view('biodata', $data);
});

Route::get('/biodata-compact', function () {
    $nim = "10522094";
    $nama = "Adinda Natasya";
    $kelas = "IS-3";
    $jurusan = "Sistem Informasi";
    $alamat = "Komp. Bukit Cinunuk Lestari Blok A-2 Jl. Ciguruwik";

    return view('biodata', compact('nim', 'nama', 'kelas', 'jurusan', 'alamat'));
});

// Route Tantangan 2 
Route::get('/produk/create', [ProdukController::class, 'create']);
Route::post('/produk/store', [ProdukController::class, 'store'])->name('produk.store');
// file 5
Route::get('/produk', [ProdukController::class, 'index'])->name('produk.index');
Route::get('/produk/edit/{id}', [ProdukController::class, 'edit'])->name('produk.edit');
Route::post('/produk/update/{id}', [ProdukController::class, 'update'])->name('produk.update');
Route::delete('/produk/destroy/{id}', [ProdukController::class, 'destroy'])->name('produk.destroy');
// Pelanggan
Route::get('/pelanggan', [PelangganController::class, 'index'])->name('pelanggan.index');
Route::get('/pelanggan/create', [PelangganController::class, 'create'])->name('pelanggan.create');
Route::post('/pelanggan/store', [PelangganController::class, 'store'])->name('pelanggan.store');
Route::get('/pelanggan/edit/{id}', [PelangganController::class, 'edit']);
Route::post('/pelanggan/update/{id}', [PelangganController::class, 'update']);
Route::delete('/pelanggan/destroy/{id}', [PelangganController::class, 'destroy']);