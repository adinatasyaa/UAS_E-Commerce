<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class Produk extends Model
{
    use HasFactory;

    protected $table = 'produk';
    protected $fillable = [
        'nama_produk',
        'id_kategori_produk', 
        'stok',
        'harga_produk',
        'foto_produk'
    ];
    
    public function kategori()
    {
        return $this->belongsTo(Kategori::class, 'id_kategori_produk', 'id');
    }

    public function getFotoProdukAttribute()
    {
        $foto_produk = $this->attributes['foto_produk'] ?? null;

        if (empty($foto_produk)) {
            return 'https://via.placeholder.com/100?text=Produk';
        }
        
        return Storage::url('produk/' . $foto_produk);
    }
}