<?php

namespace App\Http\Controllers;

use App\Models\Pelanggan;
use Illuminate\Http\Request;

class PelangganController extends Controller
{
    
    public function index(Request $request)
    {
        $q = $request->get('q');

        $result = Pelanggan::where(function($query) use($q) {
            $query->whereAny(['nama_lengkap', 'nomor_hp', 'alamat_email'], 'LIKE', '%' . $q . '%');
        })->paginate(20); 

        return view('pelanggan.list', compact('result', 'q'));
    }
    
    public function create()
    {
        return view('pelanggan.form');
    }

    public function store(Request $request)
    {
        $rules = [
            'nama_lengkap'   => 'required|min:3|max:100',
            'jenis_kelamin'  => 'required',
            'nomor_hp'       => 'required|numeric',
            'alamat_email'   => 'required|email',
            'foto_pelanggan' => 'nullable|image|mimes:jpeg,png,jpg|max:2048', 
        ];

        $request->validate($rules);
        $input = $request->all();

        if ($request->hasFile('foto_pelanggan')) {
            $fileName = $request->foto_pelanggan->getClientOriginalName();
            $request->foto_pelanggan->storeAs('pelanggan', $fileName);
            $input['foto_pelanggan'] = $fileName;
        }

        Pelanggan::create($input);

        return redirect('pelanggan')->with('success', 'Data pelanggan berhasil disimpan');
    }
    public function edit($id)
    {
        $pelanggan = Pelanggan::findOrFail($id);
        return view('pelanggan.edit', compact('pelanggan'));
    }

    public function update(Request $request, $id)
    {
        $pelanggan = Pelanggan::findOrFail($id);
        $rules = [
            'nama_lengkap'   => 'required|min:3|max:100',
            'jenis_kelamin'  => 'required',
            'nomor_hp'       => 'required|numeric',
            'alamat_email'   => 'required|email',
            'foto_pelanggan' => 'nullable|image|mimes:jpeg,png,jpg|max:2048', 
        ];

        $request->validate($rules);
        $input = $request->all();

        if ($request->hasFile('foto_pelanggan')) {
            if (!empty($pelanggan->getRawOriginal('foto_pelanggan'))) {
                \Storage::delete('pelanggan/' . $pelanggan->getRawOriginal('foto_pelanggan'));
            }

            $fileName = $request->foto_pelanggan->getClientOriginalName();
            $request->foto_pelanggan->storeAs('pelanggan', $fileName);
            $input['foto_pelanggan'] = $fileName;
        }

        $pelanggan->update($input);
        return redirect('pelanggan')->with('success', 'Data pelanggan berhasil diperbarui');
    }

    public function destroy($id)
    {
        $pelanggan = Pelanggan::findOrFail($id);

        if (!empty($pelanggan->getRawOriginal('foto_pelanggan'))) {
            \Storage::delete('pelanggan/' . $pelanggan->getRawOriginal('foto_pelanggan'));
        }

        $pelanggan->delete();
        return redirect('pelanggan')->with('success', 'Data pelanggan berhasil dihapus');
    }
}