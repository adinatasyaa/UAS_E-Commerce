<?php

namespace App\Http\Controllers;

use App\Models\Produk;
use Illuminate\Http\Request;

class ProdukController extends Controller
{
    public function index(Request $request)
    {
       $q = $request->get('q');

       $data['q'] = $q;

       $data['result'] = Produk::where(function ($query) use ($q) {
            $query->where('nama_produk', 'like', '%' . $q . '%')
                ->orWhere('stok', 'like', '%' . $q . '%')
                ->orWhere('harga_produk', 'like', '%' . $q . '%')
                ->orWhereHas('kategori', function  ($queryKategori) use ($q) {
                    $queryKategori->where('nama_kategori', 'like', '%' . $q . '%');
                });
       })->paginate();

       $data['q'] = $q;
       
       return view('produk.list', $data);
    }

    public function create()
    {
        $kategori = \App\Models\Kategori::all();
        return view('produk.form', compact('kategori'));
    }

    public function store(Request $request)
    {
        $rules = [
            'id_kategori_produk' => 'required', 
            'nama_produk'        => 'required|min:5|max:50',
            'stok'               => 'required|numeric',
            'harga_produk'       => 'required|numeric|min:1000',
            'foto_produk'        => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        ];

        $request->validate($rules);
        $input = $request->all();

        if ($request->hasFile('foto_produk')) {
            $fileName = $request->foto_produk->getClientOriginalName();
            $request->foto_produk->storeAs('produk', $fileName);
            $input['foto_produk'] = $fileName;
        }
        
        Produk::create($input);

        return redirect('produk')->with('success', 'Data produk berhasil disimpan');
    }

    public function edit($id)
    {
        $produk = Produk::findOrFail($id);
        $kategori = \App\Models\Kategori::all();
        
        return view('produk.edit', compact('produk', 'kategori'));
    }

    public function update(Request $request, $id)
    {
        $produk = Produk::findOrFail($id);
        $rules = [
            'id_kategori_produk' => 'required',
            'nama_produk'        => 'required|min:5|max:50',
            'stok'               => 'required|numeric',
            'harga_produk'       => 'required|numeric|min:1000',
            'foto_produk'        => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        ];
        
        $request->validate($rules);
        $input = $request->all();

        if ($request->hasFile('foto_produk')) {
            if (!empty($produk->getRawOriginal('foto_produk'))) {
                \Storage::delete('produk/' . $produk->getRawOriginal('foto_produk'));
            }

            $fileName = $request->foto_produk->getClientOriginalName();
            $request->foto_produk->storeAs('produk', $fileName);
            $input['foto_produk'] = $fileName;
        }
        
        $produk->update($input);
        
        return redirect('produk')->with('success', 'Data produk berhasil diperbarui');
    }

    public function destroy($id)
    {
        $produk = Produk::findOrFail($id);

        if (!empty($produk->getRawOriginal('foto_produk'))) {
            \Storage::delete('produk/' . $produk->getRawOriginal('foto_produk'));
        }

        $produk->delete();

        return redirect('produk')->with('success', 'Data produk berhasil dihapus');
    }
} 