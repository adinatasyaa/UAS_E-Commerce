<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Biodata Saya</title>
</head>
<body>
    <h2>Biodata Saya</h2>
    <table border="1" cellpadding="10" cellspacing="0" style="width: 500px;">
        <tr>
            <td width="150">NIM</td>
            <td><?php echo e($nim); ?></td>
        </tr>
        <tr>
            <td>Nama Lengkap</td>
            <td><?php echo e($nama); ?></td>
        </tr>
        <tr>
            <td>Kelas</td>
            <td><?php echo e($kelas); ?></td>
        </tr>
        <tr>
            <td>Jurusan</td>
            <td><?php echo e($jurusan); ?></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td><?php echo e($alamat); ?></td>
        </tr>
    </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\tugas-laravel\tugas-ecommerce\resources\views/biodata.blade.php ENDPATH**/ ?>