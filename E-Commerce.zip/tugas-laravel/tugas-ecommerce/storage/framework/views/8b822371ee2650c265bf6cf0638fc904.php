<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Biodata Dosen</title>
</head>
<body>
    <h2>Biodata Dosen Pengampu Mata Kuliah E-Commerce</h2>
    <table border="1" cellpadding="10" cellspacing="0" style="width: 500px;">
        <tr>
            <td width="150">NIP</td>
            <td><?php echo e($nip); ?></td>
        </tr>
        <tr>
            <td>NIDN</td>
            <td><?php echo e($nidn); ?></td>
        </tr>
        <tr>
            <td>Nama Lengkap</td>
            <td><?php echo e($nama); ?></td>
        </tr>
        <tr>
            <td>Tempat Lahir</td>
            <td><?php echo e($tempat); ?></td>
        </tr>
        <tr>
            <td>Tanggal Lahir</td>
            <td><?php echo e($tanggal); ?></td>
        </tr>
    </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\tugas-laravel\tugas-ecommerce\resources\views/dosen.blade.php ENDPATH**/ ?>