<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Data Produk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card-detail {
            max-width: 500px;
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }
        .table th {
            background-color: #fdfdfd;
            width: 35%;
        }
    </style>
</head>
<body class="d-flex align-items-center justify-content-center min-vh-screen">

    <div class="card card-detail p-4 bg-white w-100">
        <div class="alert alert-success d-flex align-items-center rounded-3 shadow-sm mb-4" role="alert">
            <svg class="bi flex-shrink-0 me-2" width="18" height="18" fill="currentColor" viewBox="0 0 16 16" style="margin-top: -2px;">
                <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
            </svg>
            <div class="small fw-semibold">
                Validasi Data Produk Berhasil Disimpan!
            </div>
        </div>

        <h2 class="fs-5 font-weight-bold text-dark mb-3">Detail Informasi Produk</h2>
        
        <div class="table-responsive border rounded-3 overflow-hidden mb-4 shadow-sm">
            <table class="table table-bordered mb-0 align-middle">
                <tbody>
                    <tr>
                        <th class="text-secondary small fw-bold px-3 py-3 border-end">Kategori Produk</th>
                        <td class="px-3 py-3 text-muted small"><?php echo e($data['kategori_produk']); ?></td>
                    </tr>
                    <tr>
                        <th class="text-secondary small fw-bold px-3 py-3 border-end">Nama Produk</th>
                        <td class="px-3 py-3 text-dark fw-medium small"><?php echo e($data['nama_produk']); ?></td>
                    </tr>
                    <tr>
                        <th class="text-secondary small fw-bold px-3 py-3 border-end">Stok</th>
                        <td class="px-3 py-3 text-muted small"><?php echo e($data['stok']); ?> Unit</td>
                    </tr>
                    <tr>
                        <th class="text-secondary small fw-bold px-3 py-3 border-end">Harga Produk</th>
                        <td class="px-3 py-3 text-primary fw-bold small">Rp <?php echo e(number_format($data['harga_produk'], 0, ',', '.')); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="text-center">
            <a href="<?php echo e(url('/produk/create')); ?>" class="btn btn-secondary px-4 py-2 small fw-medium rounded-3 shadow-sm d-inline-flex align-items-center gap-2">
                <svg width="14" height="14" fill="currentColor" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z"/>
                </svg>
                <span>Kembali ke Form</span>
            </a>
        </div>
    </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\tugas-laravel\tugas-ecommerce\resources\views/produk/show.blade.php ENDPATH**/ ?>