<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Produk</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

    <style>
        body{
            background-color:#f8f9fa;
        }

        .table-container{
            background:#fff;
            border-radius:10px;
            box-shadow:0 2px 10px rgba(0,0,0,.1);
            padding:20px;
        }

        .table img{
            width:80px;
            height:auto;
        }
    </style>
</head>
<body>

<div class="container py-5">

    <div class="table-container">

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="mb-0">Daftar Produk</h3>

            <a href="<?php echo e(url('/produk/create')); ?>" class="btn btn-primary">
                <i class="bi bi-plus-circle"></i>
                Tambah Produk
            </a>
        </div>

        <form action="<?php echo e(url('/produk')); ?>" method="GET" class="mb-4">
            <div class="input-group">
                <input
                    type="text"
                    name="q"
                    value="<?php echo e($q ?? ''); ?>"
                    class="form-control"
                    placeholder="Cari nama produk atau kategori">

                <button class="btn btn-primary" type="submit">
                    <i class="bi bi-search"></i>
                    Cari
                </button>
            </div>
        </form>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="table-responsive">

            <table class="table table-bordered table-striped align-middle">

                <thead class="table-light">
                    <tr>
                        <th>No</th>
                        <th>Foto</th>
                        <th>Kategori</th>
                        <th>Nama Produk</th>
                        <th>Stok</th>
                        <th>Harga</th>
                        <th width="150">Aksi</th>
                    </tr>
                </thead>

                <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr>

                        <td><?php echo e($loop->iteration); ?></td>

                        <td>
                            <img
                                src="<?php echo e($item->foto_produk); ?>"
                                alt="Produk"
                                class="img-thumbnail">
                        </td>

                        <td>
                            <?php echo e($item->kategori->nama_kategori ?? '-'); ?>

                        </td>

                        <td>
                            <?php echo e($item->nama_produk); ?>

                        </td>

                        <td>
                            <?php echo e($item->stok); ?>

                        </td>

                        <td>
                            Rp <?php echo e(number_format($item->harga_produk,0,',','.')); ?>

                        </td>

                        <td>

                            <a href="<?php echo e(url('/produk/edit/'.$item->id)); ?>"
                               class="btn btn-warning btn-sm">
                                Edit
                            </a>

                            <form action="<?php echo e(url('/produk/destroy/'.$item->id)); ?>"
                                  method="POST"
                                  class="d-inline">

                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <button
                                    type="submit"
                                    class="btn btn-danger btn-sm"
                                    onclick="return confirm('Yakin hapus data?')">
                                    Hapus
                                </button>

                            </form>

                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>
                        <td colspan="7" class="text-center">
                            Data produk tidak ditemukan
                        </td>
                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

                </div>

        <div class="d-flex justify-content-center mt-4">
    <?php echo e($result->links('pagination::bootstrap-5')); ?>

</div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html><?php /**PATH C:\xampp\htdocs\tugas-laravel\tugas-ecommerce\resources\views/produk/list.blade.php ENDPATH**/ ?>