<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body{
            background:#f8f9fa;
        }
    </style>
</head>
<body>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-6 col-md-8">

            <div class="card shadow border-0">
                <div class="card-body p-4">

                    <h3 class="text-center mb-4">
                        Edit Produk
                    </h3>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(url('/produk/update/'.$produk->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="mb-3">
                            <label class="form-label">Kategori Produk</label>

                            <select name="id_kategori_produk" class="form-select">
                                <option value="">Pilih Kategori</option>

                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kat->id); ?>"
                                        <?php echo e(old('id_kategori_produk',$produk->id_kategori_produk)==$kat->id ? 'selected' : ''); ?>>
                                        <?php echo e($kat->nama_kategori); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Nama Produk</label>

                            <input type="text"
                                   name="nama_produk"
                                   value="<?php echo e(old('nama_produk',$produk->nama_produk)); ?>"
                                   class="form-control">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Stok</label>

                            <input type="number"
                                   name="stok"
                                   value="<?php echo e(old('stok',$produk->stok)); ?>"
                                   class="form-control">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Harga Produk</label>

                            <input type="number"
                                   name="harga_produk"
                                   value="<?php echo e(old('harga_produk',$produk->harga_produk)); ?>"
                                   class="form-control">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Foto Produk</label>

                            <?php if(!empty($produk->getRawOriginal('foto_produk'))): ?>

                                <div class="mb-2">
                                    <img
                                        src="<?php echo e(Storage::url('produk/'.$produk->getRawOriginal('foto_produk'))); ?>"
                                        width="120"
                                        class="img-thumbnail">
                                </div>

                            <?php endif; ?>

                            <input type="file"
                                   name="foto_produk"
                                   class="form-control">

                            <small class="text-muted">
                                Kosongkan jika tidak ingin mengubah foto.
                            </small>
                        </div>

                        <div class="d-flex gap-2">
                            <a href="<?php echo e(url('/produk')); ?>"
                               class="btn btn-secondary w-50">
                                Kembali
                            </a>

                            <button type="submit"
                                    class="btn btn-warning w-50 text-white">
                                Update Produk
                            </button>
                        </div>

                    </form>

                </div>
            </div>

        </div>
    </div>
</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\tugas-laravel\tugas-ecommerce\resources\views/produk/edit.blade.php ENDPATH**/ ?>