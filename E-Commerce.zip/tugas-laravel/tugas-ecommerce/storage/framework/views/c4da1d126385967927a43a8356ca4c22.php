<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Pelanggan</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

    <style>
        .pagination svg {
            width: 16px;
            height: 16px;
        }
    </style>
</head>
<body class="container py-5">
    <div class="p-4 bg-white shadow-sm rounded-3">
        
        <form action="<?php echo e(url('/pelanggan')); ?>" method="GET" class="row mb-4 align-items-center">
            <div class="col-md-4">
                <div class="input-group">
                    <input type="text" name="q" value="<?php echo e($q ?? ''); ?>" placeholder="Cari pelanggan..." class="form-control bg-light">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-search"></i> Cari
                    </button>
                </div>
            </div>
            <div class="col-md-8 text-end">
                <a href="<?php echo e(url('/pelanggan/create')); ?>" class="btn btn-primary px-4">Tambah</a>
            </div>
        </form>
        <?php if(session('success')): ?> 
            <div class="alert alert-success rounded-3"><?php echo e(session('success')); ?></div> 
        <?php endif; ?>

        <table class="table table-bordered table-striped align-middle">
            <thead class="table-light">
                <tr>
                    <th width="5%">No</th>
                    <th width="15%">Foto</th>
                    <th>Nama Pelanggan</th>
                    <th>Jenis Kelamin</th>
                    <th>Nomor HP</th>
                    <th>Email</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($result->firstItem() + $loop->index); ?></td>
                    <td><img src="<?php echo e($item->foto_pelanggan); ?>" alt="Foto" width="80px" class="img-thumbnail rounded-3" /></td>
                    <td><?php echo e($item->nama_lengkap); ?></td>
                    <td><?php echo e($item->jenis_kelamin); ?></td>
                    <td><?php echo e($item->nomor_hp); ?></td>
                    <td><?php echo e($item->alamat_email); ?></td>
                <td class="text-center">
                    <a href="<?php echo e(url('/pelanggan/edit/'.$item->id)); ?>"class="btn btn-warning btn-sm">
                        Edit
                    </a>
                    <form action="<?php echo e(url('/pelanggan/destroy/'.$item->id)); ?>"
                        method="POST"
                        class="d-inline">

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>

                        <button type="submit"
                            class="btn btn-danger btn-sm"
                            onclick="return confirm('Yakin hapus data?')">
                            Hapus
                        </button>
                    </form>
                </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="text-center text-muted py-4">Data pelanggan kosong.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="mt-3">
            <?php echo e($result->appends(['q' => $q ?? ''])->links()); ?>

        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\tugas-laravel\tugas-ecommerce\resources\views/pelanggan/list.blade.php ENDPATH**/ ?>