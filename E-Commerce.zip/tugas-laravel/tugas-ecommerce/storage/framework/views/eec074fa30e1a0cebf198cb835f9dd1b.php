<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Edit Pelanggan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .card-form { max-width: 450px; border: none; border-radius: 12px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05); }
    </style>
</head>
<body class="d-flex align-items-center justify-content-center min-vh-screen py-5">

    <div class="card card-form p-4 bg-white w-100">
        <h2 class="text-center fs-4 font-weight-bold text-dark mb-4">Form Edit Pelanggan</h2>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger rounded-3 shadow-sm mb-4" role="alert">
                <ul class="mb-0 ps-3 small">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(url('/pelanggan/update/'.$pelanggan->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            
            <div class="mb-3">
                <label class="form-label fw-semibold text-secondary small">Nama Lengkap:</label>
                <input type="text" name="nama_lengkap" value="<?php echo e(old('nama_lengkap', $pelanggan->nama_lengkap)); ?>" class="form-control">
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold text-secondary small">Jenis Kelamin:</label>
                <select name="jenis_kelamin" class="form-select bg-light">
                    <option value="">-Pilih Jenis Kelamin-</option>
                    <option value="Laki-laki" <?php echo e(old('jenis_kelamin', $pelanggan->jenis_kelamin) == 'Laki-laki' ? 'selected' : ''); ?>>Laki-laki</option>
                    <option value="Perempuan" <?php echo e(old('jenis_kelamin', $pelanggan->jenis_kelamin) == 'Perempuan' ? 'selected' : ''); ?>>Perempuan</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold text-secondary small">Nomor HP:</label>
                <input type="text" name="nomor_hp" value="<?php echo e(old('nomor_hp', $pelanggan->nomor_hp)); ?>" class="form-control">
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold text-secondary small">Alamat Email:</label>
                <input type="email" name="alamat_email" value="<?php echo e(old('alamat_email', $pelanggan->alamat_email)); ?>" class="form-control">
            </div>

            <div class="mb-4">
                <label class="form-label fw-semibold text-secondary small">Foto Pelanggan:</label>
                <?php if(!empty($pelanggan->getRawOriginal('foto_pelanggan')) && \Storage::exists('pelanggan/'.$pelanggan->getRawOriginal('foto_pelanggan'))): ?>
                    <div class="mb-2">
                        <img src="<?php echo e(Storage::url('pelanggan/'.$pelanggan->getRawOriginal('foto_pelanggan'))); ?>" alt="Foto Sekarang" width="120px" class="img-thumbnail rounded-3" />
                        <div class="form-text text-muted small">Foto saat ini</div>
                    </div>
                <?php endif; ?>
                <input type="file" name="foto_pelanggan" class="form-control">
                <div class="form-text text-muted small">Kosongkan jika tidak ingin mengubah foto</div>
            </div>

            <div class="d-flex gap-2">
                <a href="<?php echo e(url('/pelanggan')); ?>" class="btn btn-secondary w-50 py-2 fw-semibold rounded-3">Kembali</a>
                <button type="submit" class="btn btn-warning w-50 py-2 fw-semibold rounded-3 text-white">
                    Update Data
                </button>
            </div>
        </form>
    </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\tugas-laravel\tugas-ecommerce\resources\views/pelanggan/edit.blade.php ENDPATH**/ ?>