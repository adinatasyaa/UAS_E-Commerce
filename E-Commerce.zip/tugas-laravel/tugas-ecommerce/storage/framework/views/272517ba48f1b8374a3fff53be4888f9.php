<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Produk Sepatu</title>
</head>
<body>
    <h2>Produk Sepatu</h2>
    <table border="1" cellpadding="10" cellspacing="0" style="width: 500px;">
        <tr>
            <td width="150">Nama Produk</td>
            <td><?php echo e($nama_produk); ?></td>
        </tr>
        <tr>
            <td>Warna</td>
            <td><?php echo e($warna); ?></td>
        </tr>
        <tr>
            <td>Ukuran</td>
            <td><?php echo e($ukuran); ?></td>
        </tr>
        <tr>
            <td>Jumlah Stok</td>
            <td><?php echo e($stok); ?></td>
        </tr>
    </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\tugas-laravel\tugas-ecommerce\resources\views/produk.blade.php ENDPATH**/ ?>